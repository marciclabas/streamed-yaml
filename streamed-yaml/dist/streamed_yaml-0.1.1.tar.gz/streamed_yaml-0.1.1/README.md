# Streamed Yaml

> Parse streamed (incomplete) single-level YAML